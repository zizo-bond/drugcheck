import React, { useState } from 'react';
import { InteractionData, InteractionType } from '../types';
import Badge from './Badge';
import { GoogleGenAI } from "@google/genai";

interface Props {
  interaction: InteractionData;
}

const InteractionCard: React.FC<Props> = ({ interaction }) => {
  const [aiAnalysis, setAiAnalysis] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleAskAI = async () => {
    if (!process.env.API_KEY) {
      alert("API Key is not configured in the environment.");
      return;
    }

    setLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const model = 'gemini-2.5-flash';
      
      const prompt = `
        أنت صيدلي خبير. قم بتحليل التفاعل الدوائي التالي باختصار للعاملين في المجال الطبي:
        الدواء الأول: ${interaction.drugA}
        الطرف الثاني: ${interaction.drugB || interaction.foodOrCondition}
        النوع: ${interaction.type}
        الخطورة: ${interaction.severity}
        الآلية: ${interaction.mechanism}
        التأثير: ${interaction.effect}
        الإدارة: ${interaction.management}

        المطلوب:
        1. شرح الآلية بشكل أعمق قليلاً (سطرين).
        2. نصيحة عملية للطبيب أو الصيدلي.
        اجعل الإجابة باللغة العربية المهنية.
      `;

      const response = await ai.models.generateContent({
        model: model,
        contents: prompt,
      });

      setAiAnalysis(response.text || "لم يتم العثور على إجابة.");
    } catch (error) {
      console.error("AI Error", error);
      setAiAnalysis("عذراً، حدث خطأ أثناء الاتصال بالذكاء الاصطناعي.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 hover:shadow-md transition-shadow duration-200">
      <div className="flex flex-col md:flex-row justify-between items-start mb-4 gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              <span className="text-blue-600">{interaction.drugA}</span>
              <span className="text-slate-400 text-sm">x</span>
              <span className="text-purple-600">
                {interaction.type === InteractionType.DRUG_DRUG 
                  ? interaction.drugB 
                  : interaction.foodOrCondition}
              </span>
            </h3>
          </div>
          <div className="flex gap-2 flex-wrap">
            <Badge severity={interaction.severity} />
            <span className="px-2 py-1 rounded-md bg-slate-100 text-slate-600 text-xs font-semibold border border-slate-200">
              {interaction.type === InteractionType.DRUG_DRUG ? 'تفاعل دوائي' : 
               interaction.type === InteractionType.DRUG_FOOD ? 'تفاعل غذائي' : 'تفاعل مرضي'}
            </span>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-4 text-sm text-slate-700 bg-slate-50 p-4 rounded-lg">
        <div>
          <span className="font-bold text-slate-900 block mb-1">الآلية (Mechanism):</span>
          <p>{interaction.mechanism}</p>
        </div>
        <div>
          <span className="font-bold text-slate-900 block mb-1">التأثير (Effect):</span>
          <p>{interaction.effect}</p>
        </div>
        <div>
          <span className="font-bold text-slate-900 block mb-1">الإدارة (Management):</span>
          <p>{interaction.management}</p>
        </div>
      </div>

      {/* AI Section */}
      <div className="mt-4 pt-4 border-t border-slate-100">
        {!aiAnalysis ? (
          <button 
            onClick={handleAskAI}
            disabled={loading}
            className="text-xs flex items-center gap-1 text-indigo-600 hover:text-indigo-800 font-semibold disabled:opacity-50"
          >
            {loading ? (
              <>
                <svg className="animate-spin h-4 w-4 text-indigo-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                جاري التحليل بالذكاء الاصطناعي...
              </>
            ) : (
              <>
                ✨ تحليل تفصيلي بواسطة Gemini AI
              </>
            )}
          </button>
        ) : (
          <div className="bg-indigo-50 p-3 rounded-lg border border-indigo-100 mt-2 text-sm">
            <h4 className="font-bold text-indigo-800 mb-1 flex items-center gap-2">
              ✨ تحليل الذكاء الاصطناعي:
            </h4>
            <p className="text-indigo-900 whitespace-pre-line leading-relaxed">{aiAnalysis}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default InteractionCard;