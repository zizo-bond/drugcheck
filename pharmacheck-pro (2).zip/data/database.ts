
import { InteractionData, InteractionType, InteractionSeverity } from '../types';
import { processInteractions, extractUniqueDrugs } from '../utils/dataProcessing';

// --- Drug Classes Arrays (Based on Source Text) ---
const ANDROGENS = ['Androstanolone', 'Nandrolone decanoate', 'Nandrolone', 'Testosterone', 'Danazol', 'Fluxymesterone', 'Methyltestosterone', 'Oxandrolone', 'Oxymetholone', 'Stanozolol'];
const IRON_IV = ['Iron dextran', 'Ferric gluconate', 'Iron sucrose'];
const IRON_ORAL = ['Ferrous fumarate', 'Ferrous gluconate', 'Ferrous sulfate', 'Iron polysaccharide'];
const PHOSPHATE_BINDERS_ANTACIDS = ['Aluminum hydroxide', 'Aluminum-magnesium hydroxide', 'Calcium acetate', 'Calcium carbonate', 'Magnesium hydroxide', 'Magnesium oxide', 'Magnesium sulfate', 'Magnesium trisilicate', 'Aluminum carbonate', 'Aluminum phosphate', 'Attapulgite', 'Kaolin', 'Magaldrate'];
const BETA_BLOCKERS_CARDIO = ['Acebutolol', 'Atenolol', 'Betaxolol', 'Bisoprolol', 'Esmolol', 'Metoprolol', 'Nadolol'];
const BETA_BLOCKERS_NONCARDIO = ['Carteolol', 'Carvedilol', 'Labetalol', 'Penbutolol', 'Pindolol', 'Propranolol', 'Sotalol', 'Timolol'];
const BETA_BLOCKERS_ALL = [...BETA_BLOCKERS_CARDIO, ...BETA_BLOCKERS_NONCARDIO];
const TCAS = ['Amitriptyline', 'Amoxapine', 'Clomipramine', 'Desipramine', 'Doxepin', 'Imipramine', 'Nortriptyline', 'Protriptyline', 'Trimipramine'];
const SYMPATHOMIMETICS = ['Dobutamine', 'Dopamine', 'Ephedrine', 'Epinephrine', 'Mephentermine', 'Metaraminol', 'Methoxamine', 'Norepinephrine', 'Phenylephrine', 'Pseudoephedrine'];
const ACE_INHIBITORS = ['Benazepril', 'Captopril', 'Enalapril', 'Fosinopril', 'Lisinopril', 'Moexipril', 'Perindopril', 'Quinapril', 'Trandolapril'];
const K_SPARING_DIURETICS = ['Amiloride', 'Spironolactone', 'Triamterene'];
const ARBS = ['Candesartan', 'Eprosartan', 'Irbesartan', 'Losartan', 'Olmesartan', 'Telmisartan', 'Valsartan'];
const BARBITURATES = ['Amobarbital', 'Aprobarbital', 'Butabarbital', 'Butalbital', 'Mephobarbital', 'Pentobarbital', 'Phenobarbital', 'Primidone', 'Secobarbital'];
const NSAIDS = ['Ibuprofen', 'Indomethacin', 'Naproxen', 'Piroxicam', 'Diclofenac', 'Etodolac', 'Fenoprofen', 'Flubiprofen', 'Ketoprofen', 'Ketorolac', 'Meclofenamic acid', 'Nabumetone', 'Oxaprozin', 'Sulindac', 'Tolmetin', 'Celecoxib', 'Meloxicam', 'Mefenamic Acid'];
const RIFAMYCINS = ['Rifabutin', 'Rifampin', 'Rifapentine'];
const THIOAMIDES = ['Methimazole', 'Propylthiouracil'];
const INHALATION_ANESTHETICS = ['Desflurane', 'Enflurane', 'Halothane', 'Isoflurane', 'Sevoflurane'];
const QUINOLONES = ['Gatifloxacin', 'Moxifloxacin', 'Sparfloxacin', 'Ciprofloxacin', 'Gemifloxacin', 'Levofloxacin', 'Lomefloxacin', 'Nalidixic Acid', 'Norfloxacin', 'Ofloxacin', 'Trovafloxacin'];
const BENZODIAZEPINES = ['Alprazolam', 'Clonazepam', 'Diazepam', 'Lorazepam', 'Midazolam', 'Triazolam'];
const STATINS = ['Fluvastatin', 'Lovastatin', 'Simvastatin', 'Atorvastatin', 'Pravastatin', 'Rosuvastatin'];
const HYDANTOINS = ['Ethotoin', 'Fosphenytoin', 'Mephenytoin', 'Phenytoin'];
const CALCIUM_SALTS = ['Calcium acetate', 'Calcium carbonate', 'Calcium chloride', 'Calcium citrate', 'Calcium glubionate', 'Calcium gluconate', 'Calcium glycerophosphate', 'Calcium lactate', 'Calcium levulinate', 'Tricalcium phosphate'];
const NONDEPOLARIZING_MUSCLE_RELAXANTS = ['Atracurium', 'Doxacurium', 'Mivacurium', 'Pancuronium', 'Pipecuronium', 'Rocuronium', 'Tubocurarine', 'Vecuronium', 'Gallamine triethiodide'];
const PROTEASE_INHIBITORS = ['Indinavir', 'Ritonavir', 'Nelfinavir', 'Saquinavir', 'Amprenavir', 'Fosamprenavir', 'Lopinavir', 'Atazanavir', 'Tipranavir', 'Darunavir'];
const PDE5_INHIBITORS = ['Sildenafil', 'Tadalafil', 'Vardenafil'];
const AMINOGLYCOSIDES = ['Amikacin', 'Gentamicin', 'Kanamycin', 'Neomycin', 'Streptomycin', 'Tobramycin', 'Paromomycin'];
const CEPHALOSPORINS = ['Cefamandole', 'Cefazolin', 'Cefonicid', 'Cefoperazone', 'Cefotaxime', 'Cefotetan', 'Cefoxitin', 'Ceftazidime', 'Ceftizoxime', 'Ceftriaxone', 'Cefuroxime', 'Cephalothin', 'Cephapirin', 'Cephradine'];
const PENICILLINS = ['Amoxicillin', 'Ampicillin', 'Bacampicillin', 'Carbenicillin', 'Cloxacillin', 'Dicloxacillin', 'Methicillin', 'Mezlocillin', 'Nafcillin', 'Oxacillin', 'Penicillin G', 'Penicillin V', 'Piperacillin', 'Ticarcillin'];
const MACROLIDES = ['Azithromycin', 'Clarithromycin', 'Erythromycin', 'Troleandomycin'];
const TETRACYCLINES = ['Demeclocycline', 'Doxycycline', 'Methacycline', 'Minocycline', 'Oxytetracycline', 'Tetracycline'];
const BISMUTH_SALTS = ['Bismuth subgallate', 'Bismuth subsalicylate'];
const URINARY_ALKALINIZERS = ['Potassium citrate', 'Sodium acetate', 'Sodium bicarbonate', 'Sodium citrate', 'Sodium lactate', 'Tromethamine'];
const ZINC_SALTS = ['Zinc gluconate', 'Zinc sulfate'];
const ALUMINUM_SALTS = ['Aluminum carbonate', 'Aluminum hydroxide', 'Aluminum phosphate', 'Attapulgite', 'Kaolin', 'Magaldrate'];
const AZOLE_ANTIFUNGALS = ['Fluconazole', 'Itraconazole', 'Ketoconazole', 'Miconazole', 'Voriconazole'];
const H2_ANTAGONISTS = ['Cimetidine', 'Famotidine', 'Nizatidine', 'Ranitidine'];
const PPIS = ['Esomeprazole', 'Lansoprazole', 'Omeprazole', 'Pantoprazole', 'Rabeprazole'];
const SULFONAMIDES = ['Sulfadiazine', 'Sulfamethizole', 'Sulfamethoxazole', 'Sulfasalazine', 'Sulfisoxazole', 'Trimethoprim/Sulfamethoxazole'];
const ANTINEOPLASTICS = ['Bleomycin', 'Carboplatin', 'Carmustine', 'Cisplatin', 'Cyclophosphamide', 'Cytarabine', 'Doxorubicin', 'Methotrexate', 'Vinblastine', 'Vincristine'];
const THYROID_HORMONES = ['Levothyroxine', 'Liothyronine', 'Liotrix', 'Thyroid'];
const FIBRATES = ['Clofibrate', 'Fenofibrate', 'Gemfibrozil'];
const SULFONYLUREAS = ['Acetohexamide', 'Chlorpropamide', 'Glimepiride', 'Glipizide', 'Glyburide', 'Tolazamide', 'Tolbutamide'];
const CORTICOSTEROIDS = ['Betamethasone', 'Cortisone', 'Dexamethasone', 'Hydrocortisone', 'Methylprednisolone', 'Prednisolone', 'Prednisone', 'Triamcinolone'];
const MAOI_INHIBITORS = ['Isocarboxazid', 'Phenelzine', 'Tranylcypromine'];
const LOOP_DIURETICS = ['Bumetanide', 'Ethacrynic acid', 'Furosemide', 'Torsemide'];
const THIAZIDE_DIURETICS = ['Bendroflumethiazide', 'Chlorothiazide', 'Chlorthalidone', 'Hydrochlorothiazide', 'Hydroflumethiazide', 'Indapamide', 'Metolazone', 'Polythiazide', 'Trichlormethiazide'];
const PHENOTHIAZINES = ['Chlorpromazine', 'Thioridazine', 'Mesoridazine', 'Fluphenazine', 'Perphenazine', 'Prochlorperazine', 'Trifluoperazine'];

// --- Helper Function to Generate Interactions ---
const rawInteractions: InteractionData[] = [];

const add = (
  drugsA: string[] | string,
  drugsB: string[] | string,
  type: InteractionType,
  severity: InteractionSeverity,
  mechanism: string,
  effect: string,
  management: string
) => {
  const listA = Array.isArray(drugsA) ? drugsA : [drugsA];
  const listB = Array.isArray(drugsB) ? drugsB : [drugsB];

  listA.forEach(a => {
    listB.forEach(b => {
      if (a === b) return;
      rawInteractions.push({
        id: `${a}-${b}-${Math.random().toString(36).substr(2, 9)}`,
        drugA: a,
        drugB: type === InteractionType.DRUG_DRUG ? b : undefined,
        foodOrCondition: type !== InteractionType.DRUG_DRUG ? b : undefined,
        type,
        severity,
        mechanism,
        effect,
        management
      });
    });
  });
};

// ============================================================================
// 1. ANEMIA AGENTS
// ============================================================================
add(ANDROGENS, 'Warfarin', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Increased effects of warfarin', 'Increased risk of bleeding', 'Avoid combination if possible. Monitor INR and decrease warfarin dose if necessary.');
add(ANDROGENS, 'Cyclosporine', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Unknown mechanism', 'Increased risk of cyclosporine toxicity', 'Monitor cyclosporine levels.');
add('Oxymetholone', 'Warfarin', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Increased effects of warfarin', 'Increased bleeding risk', 'Monitor INR.');
add(IRON_IV, 'Chloramphenicol', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Unknown', 'Increased concentrations of iron', 'Use alternative antibiotic if possible. Monitor iron stores.');
add(IRON_ORAL, 'Chloramphenicol', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Unknown', 'Increased concentrations of iron', 'Use alternative antibiotic if possible. Monitor iron stores.');
add(IRON_ORAL, 'Levodopa', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Decreased GI absorption', 'Decreased effect of Levodopa', 'Separate administration times.');
add(IRON_ORAL, 'Levothyroxine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Decreased GI absorption', 'Decreased effect of Levothyroxine', 'Separate administration by at least 4 hours.');
add(IRON_ORAL, 'Mycophenolate mofetil', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Decreased GI absorption', 'Decreased effect', 'Separate administration.');
add(IRON_ORAL, 'Penicillamine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Decreased GI absorption', 'Decreased effect of penicillamine', 'Administer penicillamine on an empty stomach. Separate administration times.');
add(IRON_ORAL, PHOSPHATE_BINDERS_ANTACIDS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Binding', 'Decreased GI absorption of iron', 'Separate administration times by at least 2 hours.');
add(IRON_ORAL, QUINOLONES, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Chelation', 'Decreased GI absorption of quinolone', 'Avoid combination or separate widely.');
add(IRON_ORAL, TETRACYCLINES, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Chelation', 'Decreased GI absorption of tetracycline', 'Separate administration times by at least 3-4 hours.');

// ============================================================================
// 2. ANTIHYPERTENSIVE AND CARDIOVASCULAR AGENTS
// ============================================================================
// Clonidine
add('Clonidine', BETA_BLOCKERS_ALL, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Opposing effects on BP control', 'Increased blood pressure (rebound hypertension)', 'Monitor BP when starting/stopping. Discontinue either drug gradually.');
add('Clonidine', TCAS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition of alpha-2 receptors', 'Loss of blood pressure control. Increased risk of crisis', 'Avoid combination.');

// Methyldopa
add('Methyldopa', SYMPATHOMIMETICS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Synergistic pressor effect', 'Increased blood pressure', 'Monitor blood pressure. Discontinue sympathomimetic.');

// Prazosin
add('Prazosin', BETA_BLOCKERS_ALL, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Additive hypotensive effect', 'Increased postural hypotension', 'Monitor for symptoms of postural hypotension.');

// ACE Inhibitors
add(ACE_INHIBITORS, 'Indomethacin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Prostaglandin inhibition', 'Decreased antihypertensive effect', 'Monitor blood pressure. Discontinue indomethacin use.');
add(ACE_INHIBITORS, 'Lithium', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Reduced renal elimination of Lithium', 'Increased lithium toxicity', 'Monitor lithium levels.');
add(ACE_INHIBITORS, K_SPARING_DIURETICS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Additive hyperkalemic effect', 'Elevated serum potassium', 'Monitor serum potassium.');
add('Captopril', 'Food', InteractionType.DRUG_FOOD, InteractionSeverity.MODERATE, 'Reduced absorption', 'Decreased GI absorption of captopril', 'Administer captopril 1 hour before meals.');

// ARBs
add(ARBS, 'Lithium', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Reduced renal elimination', 'Increased concentrations of lithium', 'Monitor lithium levels.');

// Beta Blockers General
add(BETA_BLOCKERS_ALL, BARBITURATES, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Increased metabolism', 'Decreased bioavailability of beta-blocker', 'Increase beta-blocker dose if necessary.');
add(BETA_BLOCKERS_ALL, 'Cimetidine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibited metabolism', 'Increased concentrations of beta-blocker', 'Monitor cardiovascular status. Decrease beta-blocker dose if necessary.');
add(BETA_BLOCKERS_ALL, 'Hydralazine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Unknown', 'Increased concentrations of both drugs', 'Decrease dose of one or both drugs if necessary.');
add(BETA_BLOCKERS_ALL, NSAIDS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Prostaglandin inhibition', 'Decreased effects of beta-blocker', 'Use noninteracting NSAID if possible (eg. sulindac). Monitor blood pressure.');
add(BETA_BLOCKERS_ALL, 'Propafenone', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibited metabolism', 'Increased effects of beta-blocker', 'Monitor cardiovascular status. Decrease beta-blocker dose if necessary.');
add(BETA_BLOCKERS_ALL, 'Quinidine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibited metabolism (CYP2D6)', 'Increased effects of beta-blocker', 'Monitor cardiovascular status. Decrease beta-blocker dose if necessary.');
add(BETA_BLOCKERS_ALL, RIFAMYCINS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction of metabolism', 'Decreased effects of beta-blocker', 'Monitor cardiovascular status. Increase beta-blocker dose if necessary.');
add(BETA_BLOCKERS_ALL, 'Verapamil', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Additive AV nodal suppression', 'Increased effects of both drugs (bradycardia, heart block)', 'Monitor cardiovascular status. Decrease dose of one or both drugs if necessary.');

// Non-Selective Beta Blockers
add(BETA_BLOCKERS_NONCARDIO, 'Epinephrine', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Unopposed alpha stimulation', 'Initial hypertensive episode, followed by reflex bradycardia', 'Avoid combination. Monitor vital signs.');
add(BETA_BLOCKERS_NONCARDIO, 'Ergot Alkaloids', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Additive vasoconstriction', 'Peripheral ischemia', 'Avoid combination.');
add(BETA_BLOCKERS_NONCARDIO, 'Insulin', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Masking of hypoglycemic symptoms', 'Masked hypoglycemia / Delayed recovery', 'Monitor glucose carefully.');
add(BETA_BLOCKERS_NONCARDIO, 'Prazosin', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Additive hypotension', 'First-dose syncope', 'Monitor BP.');
add(BETA_BLOCKERS_NONCARDIO, 'Theophylline', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Mutual inhibition', 'Decreased clearance of both', 'Monitor levels.');

// Specific Beta Blockers
add('Atenolol', 'Ampicillin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Reduced absorption', 'Decreased effects of atenolol', 'Separate administration times. Monitor BP.');
add('Carvedilol', 'Cyclosporine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'P-gp inhibition', 'Increased cyclosporine levels', 'Monitor cyclosporine levels.');
add('Labetalol', INHALATION_ANESTHETICS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Additive hypotension', 'Excessive hypotension', 'Monitor blood pressure. Use combination with caution.');
add('Metoprolol', 'Lidocaine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Reduced hepatic clearance', 'Increased lidocaine levels', 'Monitor lidocaine levels.');
add('Metoprolol', THIOAMIDES, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Reduced metabolism', 'Increased effects of metoprolol', 'Monitor cardiovascular status. Decrease dose if necessary.');
add('Nadolol', 'Lidocaine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Reduced clearance', 'Increased lidocaine levels', 'Monitor lidocaine levels.');
add('Pindolol', 'Lidocaine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Reduced clearance', 'Increased lidocaine levels', 'Monitor lidocaine levels.');
add('Pindolol', PHENOTHIAZINES, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Unknown', 'Increased effects of one or both drugs', 'Decrease dose if necessary.');
add('Propranolol', 'Lidocaine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Reduced hepatic clearance', 'Increased lidocaine levels', 'Decrease dose if necessary.');
add('Propranolol', PHENOTHIAZINES, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Unknown', 'Increased effects of one or both drugs', 'Decrease dose if necessary.');
add('Propranolol', THIOAMIDES, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Reduced metabolism', 'Increased effects of propranolol', 'Monitor cardiovascular status. Decrease dose if necessary.');
add('Sotalol', ['Gatifloxacin', 'Moxifloxacin', 'Sparfloxacin'], InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'QT prolongation', 'Increased risk of cardiac arrhythmias (torsades de pointes)', 'Avoid combination. Use alternative quinolones.');

// Calcium-Channel Blockers
add('Bepridil', 'Digoxin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Unknown', 'Increased digoxin levels', 'Monitor digoxin levels.');
add('Bepridil', ['Gatifloxacin', 'Moxifloxacin', 'Sparfloxacin'], InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'QT prolongation', 'Increased risk of arrhythmias', 'Avoid combination.');
add('Bepridil', 'Ritonavir', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'CYP3A4 inhibition', 'Increased bepridil levels', 'Avoid combination.');

add('Diltiazem', BENZODIAZEPINES, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'CYP3A4 inhibition', 'Increased sedation', 'Monitor sedation.');
add('Diltiazem', 'Carbamazepine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'CYP3A4 inhibition', 'Increased carbamazepine levels', 'Monitor levels.');
add('Diltiazem', 'Cyclosporine', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'CYP3A4 inhibition', 'Increased cyclosporine levels', 'Monitor levels.');
add('Diltiazem', STATINS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'CYP3A4 inhibition', 'Increased statin levels / Myopathy risk', 'Use statin not metabolized by CYP3A4 or reduce dose.');
add('Diltiazem', 'Moricizine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Unknown', 'Increased moricizine / Decreased diltiazem', 'Adjust doses.');
add('Diltiazem', 'Quinidine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased quinidine levels', 'Monitor levels.');
add('Diltiazem', 'Sirolimus', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased sirolimus levels', 'Monitor levels.');
add('Diltiazem', 'Tacrolimus', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased tacrolimus levels', 'Monitor levels.');
add('Diltiazem', ['Aminophylline', 'Oxtriphylline', 'Theophylline'], InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'CYP1A2 inhibition', 'Increased theophylline levels', 'Monitor levels.');

add('Felodipine', BARBITURATES, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased felodipine effects', 'Monitor cardiovascular status.');
add('Felodipine', 'Carbamazepine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased felodipine effects', 'Monitor cardiovascular status.');
add('Felodipine', 'Erythromycin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased felodipine effects', 'Monitor cardiovascular status.');
add('Felodipine', 'Grapefruit Juice', InteractionType.DRUG_FOOD, InteractionSeverity.MODERATE, 'CYP3A4 Inhibition', 'Increased effects of felodipine', 'Avoid combination.');
add('Felodipine', HYDANTOINS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased felodipine effects', 'Monitor cardiovascular status.');
add('Felodipine', 'Itraconazole', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased felodipine effects', 'Monitor cardiovascular status.');

add('Nicardipine', 'Cyclosporine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased cyclosporine levels', 'Monitor levels.');

add('Nifedipine', BARBITURATES, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased nifedipine effects', 'Monitor cardiovascular status.');
add('Nifedipine', 'Cimetidine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased nifedipine effects', 'Adjust nifedipine dose.');
add('Nifedipine', 'Rifampin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased nifedipine effects', 'Adjust nifedipine dose.');
add('Nifedipine', 'Tacrolimus', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased tacrolimus levels', 'Monitor levels.');

add('Nisoldipine', 'Grapefruit Juice', InteractionType.DRUG_FOOD, InteractionSeverity.MODERATE, 'CYP3A4 Inhibition', 'Increased effects of nisoldipine', 'Avoid combination.');
add('Nisoldipine', HYDANTOINS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased effects of nisoldipine', 'Monitor cardiovascular status.');

add('Verapamil', BETA_BLOCKERS_ALL, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Additive', 'Increased effects of both drugs', 'Monitor cardiovascular status.');
add('Verapamil', CALCIUM_SALTS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Antagonism', 'Reverse clinical effects of verapamil', 'Monitor cardiovascular status.');
add('Verapamil', 'Carbamazepine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased carbamazepine levels', 'Monitor levels.');
add('Verapamil', 'Cyclosporine', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased cyclosporine levels', 'Monitor levels.');
add('Verapamil', 'Digoxin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Reduced clearance', 'Increased digoxin levels', 'Monitor digoxin levels.');
add('Verapamil', 'Ethanol', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased ethanol effects', 'Avoid combination.');
add('Verapamil', STATINS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased statin levels', 'Monitor for myopathy.');
add('Verapamil', NONDEPOLARIZING_MUSCLE_RELAXANTS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Unknown', 'Prolonged respiratory depression', 'Avoid combination if possible.');
add('Verapamil', 'Prazosin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Additive', 'Hypotension', 'Monitor BP.');
add('Verapamil', 'Quinidine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased quinidine levels', 'Monitor levels.');
add('Verapamil', 'Rifampin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased effects of oral verapamil', 'Adjust verapamil dose.');

// Antiarrhythmic Agents
add('Amiodarone', 'Cyclosporine', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased cyclosporine levels', 'Monitor levels.');
add('Amiodarone', 'Digoxin', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Reduced clearance', 'Increased digoxin levels', 'Monitor digoxin levels.');
add('Amiodarone', 'Fentanyl', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Unknown', 'Profound bradycardia, hypotension', 'Avoid combination if possible.');
add('Amiodarone', HYDANTOINS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition/Induction', 'Increased hydantoin / Decreased amiodarone', 'Monitor levels of both.');
add('Amiodarone', 'Procainamide', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased procainamide levels', 'Monitor levels.');
add('Amiodarone', PROTEASE_INHIBITORS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased amiodarone levels', 'Avoid combination.');
add('Amiodarone', 'Quinidine', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased quinidine levels', 'Avoid combination.');
add('Amiodarone', ['Gatifloxacin', 'Moxifloxacin', 'Sparfloxacin'], InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'QT Prolongation', 'Arrhythmias', 'Avoid combination.');
add('Amiodarone', 'Warfarin', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'CYP2C9 Inhibition', 'Increased warfarin effects', 'Decrease warfarin dose.');

add('Disopyramide', HYDANTOINS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased disopyramide levels', 'Monitor cardiovascular status.');
add('Disopyramide', ['Gatifloxacin', 'Moxifloxacin', 'Sparfloxacin'], InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'QT Prolongation', 'Arrhythmias', 'Avoid combination.');
add('Disopyramide', 'Rifampin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased disopyramide levels', 'Monitor cardiovascular status.');

add('Flecainide', 'Ritonavir', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'CYP2D6 Inhibition', 'Increased flecainide levels', 'Avoid combination.');

add('Lidocaine', BETA_BLOCKERS_ALL, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Reduced clearance', 'Increased lidocaine levels', 'Monitor lidocaine levels.');
add('Lidocaine', 'Cimetidine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased lidocaine levels', 'Monitor lidocaine levels.');

add('Mexiletine', HYDANTOINS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased mexiletine levels', 'Monitor cardiovascular status.');
add('Mexiletine', 'Theophylline', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased theophylline levels', 'Monitor levels.');

add('Moricizine', 'Cimetidine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased moricizine levels', 'Monitor ECG.');

add('Procainamide', 'Amiodarone', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Unknown', 'Increased procainamide levels', 'Monitor levels.');
add('Procainamide', 'Cimetidine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Renal competition', 'Increased procainamide levels', 'Decrease procainamide dose.');
add('Procainamide', 'Ofloxacin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Renal competition', 'Increased procainamide levels', 'Monitor levels.');
add('Procainamide', ['Gatifloxacin', 'Moxifloxacin', 'Sparfloxacin'], InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'QT Prolongation', 'Arrhythmias', 'Use alternative.');
add('Procainamide', 'Trimethoprim', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Renal competition', 'Increased procainamide levels', 'Monitor levels.');

add('Propafenone', 'Quinidine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'CYP2D6 Inhibition', 'Increased propafenone levels', 'Monitor cardiovascular status.');
add('Propafenone', 'Ritonavir', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased propafenone levels', 'Avoid combination.');

add('Quinidine', 'Amiloride', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Unknown', 'Arrhythmias', 'Avoid combination.');
add('Quinidine', 'Amiodarone', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'QT Prolongation', 'Arrhythmias', 'Avoid combination.');
add('Quinidine', BARBITURATES, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased quinidine levels', 'Monitor levels.');
add('Quinidine', 'Cimetidine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased quinidine levels', 'Avoid combination if possible.');
add('Quinidine', 'Codeine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'CYP2D6 Inhibition', 'Decreased codeine effect', 'Monitor pain control.');
add('Quinidine', 'Digoxin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Reduced clearance', 'Increased digoxin levels', 'Monitor levels.');
add('Quinidine', 'Diltiazem', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased quinidine levels', 'Monitor levels.');
add('Quinidine', HYDANTOINS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased quinidine levels', 'Monitor levels.');
add('Quinidine', 'Itraconazole', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased quinidine levels', 'Monitor levels.');
add('Quinidine', PHOSPHATE_BINDERS_ANTACIDS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Urinary Alkalinization', 'Increased quinidine levels', 'Monitor levels.');
add('Quinidine', 'Propafenone', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'CYP2D6 Inhibition', 'Increased propafenone levels', 'Monitor levels.');
add('Quinidine', ['Gatifloxacin', 'Moxifloxacin', 'Sparfloxacin'], InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'QT Prolongation', 'Arrhythmias', 'Avoid combination.');
add('Quinidine', RIFAMYCINS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased quinidine levels', 'Monitor levels.');
add('Quinidine', 'Ritonavir', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased quinidine levels', 'Avoid combination.');
add('Quinidine', 'Verapamil', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition + Additive', 'Increased quinidine levels + hypotension', 'Avoid combination.');

// Nitrates
add(['Amyl Nitrite', 'Isosorbide Dinitrate', 'Isosorbide Mononitrate', 'Nitroglycerin'], 'Warfarin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Unknown', 'Altered anticoagulant effect', 'Monitor INR.');
add(['Amyl Nitrite', 'Isosorbide Dinitrate', 'Isosorbide Mononitrate', 'Nitroglycerin'], 'Ergot Alkaloids', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Antagonism', 'Decreased anti-anginal effect', 'Monitor effectiveness.');
add(['Amyl Nitrite', 'Isosorbide Dinitrate', 'Isosorbide Mononitrate', 'Nitroglycerin'], PDE5_INHIBITORS, InteractionType.DRUG_DRUG, InteractionSeverity.CONTRAINDICATED, 'Synergistic vasodilation', 'Severe hypotension', 'Avoid combination.');
add('Nitroglycerin', 'Alteplase', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Unknown', 'Decreased effects of tPA', 'Avoid combination.');

// Misc CV
add('Digoxin', AMINOGLYCOSIDES, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'GI flora alteration', 'Decreased digoxin levels', 'Monitor digoxin levels.');
add('Digoxin', ANTINEOPLASTICS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'GI mucosa damage', 'Decreased digoxin levels', 'Monitor digoxin levels.');
add('Digoxin', 'Cholestyramine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Binding', 'Decreased digoxin levels', 'Separate administration.');
add('Digoxin', 'Indomethacin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Reduced renal clearance', 'Increased digoxin levels (premature infants)', 'Monitor levels.');
add('Digoxin', LOOP_DIURETICS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Electrolyte disturbance', 'Increased risk of arrhythmias due to hypokalemia', 'Monitor potassium.');
add('Digoxin', MACROLIDES, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'GI flora alteration', 'Increased digoxin levels', 'Monitor levels.');
add('Digoxin', 'Metoclopramide', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Increased motility', 'Decreased digoxin levels', 'Monitor levels.');
add('Digoxin', 'Penicillamine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Unknown', 'Decreased digoxin levels', 'Monitor levels.');
add('Digoxin', 'Quinine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Reduced clearance', 'Increased digoxin levels', 'Monitor levels.');
add('Digoxin', 'Spironolactone', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Unknown', 'Decreased inotropic effects / Increased levels', 'Monitor levels.');
add('Digoxin', TETRACYCLINES, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'GI flora alteration', 'Increased digoxin levels', 'Monitor levels.');
add('Digoxin', THIAZIDE_DIURETICS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Electrolyte disturbance', 'Increased risk of arrhythmias due to hypokalemia', 'Monitor potassium.');
add('Digoxin', THIOAMIDES, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Change in thyroid status', 'Increased digoxin levels', 'Monitor levels.');
add('Digoxin', THYROID_HORMONES, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Change in thyroid status', 'Decreased digoxin levels', 'Monitor levels.');

add('Epinephrine', BETA_BLOCKERS_NONCARDIO, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Unopposed alpha stimulation', 'Hypertension followed by bradycardia', 'Avoid combination.');
add('Hydralazine', BETA_BLOCKERS_ALL, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Unknown', 'Increased levels of both drugs', 'Decrease doses.');

// 7. ANTIMICROBIAL AGENTS
// Aminoglycosides
add(AMINOGLYCOSIDES, CEPHALOSPORINS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Additive', 'Increased risk of nephrotoxicity', 'Monitor kidney function.');
add(AMINOGLYCOSIDES, LOOP_DIURETICS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Additive', 'Increased risk of auditory toxicity', 'Monitor hearing.');
add(AMINOGLYCOSIDES, NSAIDS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Reduced renal clearance', 'Increased aminoglycoside levels (premature infants)', 'Monitor levels.');
add(AMINOGLYCOSIDES, PENICILLINS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inactivation', 'Inactivation of aminoglycoside', 'Do not mix in same solution.');

// Cephalosporins
add(CEPHALOSPORINS, 'Ethanol', InteractionType.DRUG_FOOD, InteractionSeverity.MODERATE, 'Disulfiram-like reaction', 'Nausea, vomiting, flushing (specific cephalosporins)', 'Avoid alcohol.');
add(CEPHALOSPORINS, 'Warfarin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Vitamin K inhibition', 'Increased bleeding risk', 'Monitor INR.');

// Macrolides
add('Clarithromycin', 'Buspirone', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased buspirone levels', 'Monitor levels.');
add('Clarithromycin', 'Carbamazepine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased carbamazepine levels', 'Monitor levels.');
add('Clarithromycin', 'Digoxin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'P-gp Inhibition', 'Increased digoxin levels', 'Monitor levels.');
add('Clarithromycin', 'Ergot Alkaloids', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Ergot toxicity', 'Avoid combination.');
add('Clarithromycin', RIFAMYCINS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased clarithromycin effects', 'Use alternative.');
add('Clarithromycin', 'Tacrolimus', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased tacrolimus levels', 'Monitor levels.');
add('Clarithromycin', 'Warfarin', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased INR', 'Monitor INR.');

add('Erythromycin', BENZODIAZEPINES, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased sedation', 'Monitor sedation.');
add('Erythromycin', 'Bromocriptine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased bromocriptine levels', 'Monitor for toxicity.');
add('Erythromycin', 'Buspirone', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased buspirone levels', 'Monitor levels.');
add('Erythromycin', 'Carbamazepine', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Carbamazepine toxicity', 'Monitor levels.');
add('Erythromycin', 'Digoxin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'P-gp Inhibition', 'Increased digoxin levels', 'Monitor levels.');
add('Erythromycin', 'Ergot Alkaloids', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Ergot toxicity', 'Avoid combination.');
add('Erythromycin', 'Felodipine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased felodipine effects', 'Monitor levels.');
add('Erythromycin', 'Food', InteractionType.DRUG_FOOD, InteractionSeverity.LOW, 'Absorption', 'Decreased absorption', 'Take on empty stomach.');
add('Erythromycin', 'Grapefruit Juice', InteractionType.DRUG_FOOD, InteractionSeverity.MODERATE, 'Inhibition', 'Increased erythromycin levels', 'Avoid combination.');
add('Erythromycin', 'Methylprednisolone', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased steroid effects', 'Monitor levels.');
add('Erythromycin', ['Gatifloxacin', 'Moxifloxacin', 'Sparfloxacin'], InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'QT Prolongation', 'Arrhythmias', 'Avoid combination.');
add('Erythromycin', RIFAMYCINS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased erythromycin levels', 'Use alternative.');
add('Erythromycin', 'Tacrolimus', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased tacrolimus levels', 'Monitor levels.');
add('Erythromycin', 'Warfarin', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased INR', 'Monitor INR.');

// Penicillins
add(PENICILLINS, AMINOGLYCOSIDES, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inactivation', 'Inactivation of aminoglycoside', 'Do not mix.');
add(PENICILLINS, 'Food', InteractionType.DRUG_FOOD, InteractionSeverity.LOW, 'Absorption', 'Decreased absorption', 'Take on empty stomach.');
add(PENICILLINS, 'Methotrexate', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Reduced excretion', 'Methotrexate toxicity', 'Monitor levels.');
add(PENICILLINS, TETRACYCLINES, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Antagonism', 'Decreased effects of penicillin', 'Avoid combination.');
add(PENICILLINS, 'Warfarin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Unknown', 'Increased INR (high dose IV)', 'Monitor INR.');
add('Ampicillin', 'Allopurinol', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Unknown', 'Increased risk of rash', 'Monitor for rash.');
add('Ampicillin', 'Atenolol', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Reduced absorption', 'Decreased effects of atenolol', 'Separate administration times. Monitor BP.');

// Quinolones
add(QUINOLONES, 'Didanosine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Chelation', 'Decreased quinolone absorption', 'Separate administration.');
add(QUINOLONES, IRON_ORAL, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Chelation', 'Decreased quinolone absorption', 'Avoid combination.');
add(QUINOLONES, PHOSPHATE_BINDERS_ANTACIDS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Chelation', 'Decreased quinolone absorption', 'Separate administration.');
add(QUINOLONES, 'Sucralfate', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Chelation', 'Decreased quinolone absorption', 'Separate administration.');
add('Ciprofloxacin', 'Cyclosporine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Nephrotoxicity', 'Monitor levels.');
add('Ciprofloxacin', 'Milk', InteractionType.DRUG_FOOD, InteractionSeverity.MODERATE, 'Chelation', 'Decreased absorption', 'Avoid taking with milk alone.');
add('Norfloxacin', 'Theophylline', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased theophylline levels', 'Monitor levels.');
add('Norfloxacin', 'Cyclosporine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Nephrotoxicity', 'Monitor levels.');
add('Norfloxacin', 'Milk', InteractionType.DRUG_FOOD, InteractionSeverity.MODERATE, 'Chelation', 'Decreased absorption', 'Avoid taking with milk alone.');
add('Ofloxacin', 'Theophylline', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased theophylline levels', 'Monitor levels.');
add('Ofloxacin', 'Procainamide', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Renal competition', 'Increased procainamide levels', 'Monitor levels.');
add('Sparfloxacin', 'Amiodarone', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'QT Prolongation', 'Arrhythmias', 'Avoid combination.');
add('Sparfloxacin', 'Bepridil', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'QT Prolongation', 'Arrhythmias', 'Avoid combination.');
add('Sparfloxacin', 'Disopyramide', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'QT Prolongation', 'Arrhythmias', 'Avoid combination.');
add('Sparfloxacin', 'Erythromycin', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'QT Prolongation', 'Arrhythmias', 'Avoid combination.');
add('Sparfloxacin', PHENOTHIAZINES, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'QT Prolongation', 'Arrhythmias', 'Avoid combination.');
add('Sparfloxacin', 'Procainamide', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'QT Prolongation', 'Arrhythmias', 'Avoid combination.');
add('Sparfloxacin', 'Quinidine', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'QT Prolongation', 'Arrhythmias', 'Avoid combination.');
add('Sparfloxacin', 'Sotalol', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'QT Prolongation', 'Arrhythmias', 'Avoid combination.');
add('Sparfloxacin', TCAS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'QT Prolongation', 'Arrhythmias', 'Avoid combination.');

// Tetracyclines
add(TETRACYCLINES, BISMUTH_SALTS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Chelation', 'Decreased absorption', 'Separate administration.');
add(TETRACYCLINES, IRON_ORAL, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Chelation', 'Decreased absorption', 'Separate administration.');
add(TETRACYCLINES, PHOSPHATE_BINDERS_ANTACIDS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Chelation', 'Decreased absorption', 'Separate administration.');
add(TETRACYCLINES, URINARY_ALKALINIZERS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Excretion', 'Decreased tetracycline levels', 'Separate administration.');
add(TETRACYCLINES, ZINC_SALTS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Chelation', 'Decreased absorption', 'Separate administration.');
add('Doxycycline', BARBITURATES, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased doxycycline levels', 'Increase dose.');
add('Doxycycline', 'Carbamazepine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased doxycycline levels', 'Increase dose.');
add('Doxycycline', 'Digoxin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Flora alteration', 'Increased digoxin levels', 'Monitor levels.');
add('Doxycycline', HYDANTOINS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased doxycycline levels', 'Increase dose.');
add('Doxycycline', PENICILLINS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Antagonism', 'Decreased penicillin effect', 'Avoid combination.');
add('Doxycycline', RIFAMYCINS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased doxycycline levels', 'Increase dose.');
add('Minocycline', 'Digoxin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Flora alteration', 'Increased digoxin levels', 'Monitor levels.');
add('Minocycline', PENICILLINS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Antagonism', 'Decreased penicillin effect', 'Avoid combination.');

// Misc Antibiotics
add('Chloramphenicol', IRON_ORAL, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Unknown', 'Increased iron levels', 'Monitor iron.');
add('Chloramphenicol', 'Phenytoin', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Phenytoin toxicity', 'Monitor levels.');
add('Chloramphenicol', SULFONYLUREAS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Hypoglycemia', 'Monitor glucose.');
add('Chloramphenicol', 'Warfarin', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased bleeding risk', 'Monitor INR.');
add('Clindamycin', ALUMINUM_SALTS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Absorption', 'Delayed absorption', 'Separate administration.');
add('Dapsone', 'Trimethoprim', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Competition', 'Increased levels of both', 'Monitor for methemoglobinemia.');
add('Imipenem/Cilastatin', 'Cyclosporine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Unknown', 'CNS side effects', 'Monitor for tremors/confusion.');
add('Metronidazole', BARBITURATES, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased metronidazole effect', 'Increase dose.');
add('Metronidazole', 'Disulfiram', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Unknown', 'Acute psychosis', 'Avoid combination.');
add('Metronidazole', 'Ethanol', InteractionType.DRUG_FOOD, InteractionSeverity.HIGH, 'Disulfiram-like reaction', 'Nausea, vomiting', 'Avoid alcohol.');
add('Metronidazole', 'Warfarin', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased INR', 'Decrease warfarin dose.');
add('Trimethoprim/Sulfamethoxazole', 'Cyclosporine', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Unknown', 'Reduced cyclosporine effect / Nephrotoxicity', 'Monitor levels.');
add('Trimethoprim/Sulfamethoxazole', 'Dapsone', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Competition', 'Increased levels of both', 'Monitor levels.');
add('Trimethoprim/Sulfamethoxazole', 'Methotrexate', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Displacement/Inhibition', 'Marrow toxicity', 'Avoid combination.');
add('Trimethoprim/Sulfamethoxazole', 'Phenytoin', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Phenytoin toxicity', 'Monitor levels.');
add('Trimethoprim/Sulfamethoxazole', 'Procainamide', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Renal competition', 'Increased procainamide levels', 'Monitor levels.');
add('Trimethoprim/Sulfamethoxazole', SULFONYLUREAS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Hypoglycemia', 'Monitor glucose.');
add('Trimethoprim/Sulfamethoxazole', 'Warfarin', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased INR', 'Monitor INR.');
add('Vancomycin', NONDEPOLARIZING_MUSCLE_RELAXANTS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Additive', 'Prolonged respiratory depression', 'Monitor respiratory function.');

// Azoles
add(AZOLE_ANTIFUNGALS, BENZODIAZEPINES, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased sedation', 'Monitor sedation.');
add(AZOLE_ANTIFUNGALS, 'Buspirone', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased buspirone levels', 'Monitor levels.');
add(AZOLE_ANTIFUNGALS, 'Cyclosporine', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased cyclosporine levels', 'Monitor levels.');
add(AZOLE_ANTIFUNGALS, 'Dexamethasone', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased steroid levels', 'Monitor levels.');
add(AZOLE_ANTIFUNGALS, 'Grapefruit Juice', InteractionType.DRUG_FOOD, InteractionSeverity.MODERATE, 'Absorption', 'Decreased antifungal absorption', 'Avoid combination.');
add(AZOLE_ANTIFUNGALS, 'Haloperidol', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Haloperidol toxicity', 'Monitor levels.');
add(AZOLE_ANTIFUNGALS, STATINS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Rhabdomyolysis', 'Avoid combination.');
add(AZOLE_ANTIFUNGALS, 'Indinavir', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased indinavir levels', 'Monitor levels.');
add(AZOLE_ANTIFUNGALS, 'Methylprednisolone', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased steroid levels', 'Monitor levels.');
add(AZOLE_ANTIFUNGALS, ['Prednisolone', 'Prednisone'], InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased steroid levels', 'Monitor levels.');
add(AZOLE_ANTIFUNGALS, RIFAMYCINS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased antifungal levels', 'Avoid combination.');
add(AZOLE_ANTIFUNGALS, 'Ritonavir', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased protease inhibitor levels', 'Monitor levels.');
add(AZOLE_ANTIFUNGALS, 'Saquinavir', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased protease inhibitor levels', 'Monitor levels.');
add(AZOLE_ANTIFUNGALS, 'Tacrolimus', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased tacrolimus levels', 'Monitor levels.');
add(AZOLE_ANTIFUNGALS, 'Warfarin', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased INR', 'Monitor INR.');

add('Fluconazole', ['Glimepiride', 'Tolbutamide'], InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Hypoglycemia', 'Monitor glucose.');
add('Itraconazole', 'Didanosine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'pH change', 'Decreased absorption', 'Separate administration.');
add('Itraconazole', 'Digoxin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'P-gp inhibition', 'Increased digoxin levels', 'Monitor levels.');
add('Itraconazole', 'Felodipine', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased felodipine levels', 'Monitor levels.');
add('Itraconazole', ['Food', 'Cola'], InteractionType.DRUG_FOOD, InteractionSeverity.LOW, 'Absorption', 'Increased absorption', 'Take with food/cola.');
add('Itraconazole', HYDANTOINS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Induction', 'Decreased itraconazole levels', 'Avoid combination.');
add('Itraconazole', PPIS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'pH change', 'Decreased itraconazole absorption', 'Avoid combination or use cola.');
add('Itraconazole', 'Quinidine', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Quinidine toxicity', 'Avoid combination.');
add('Ketoconazole', 'Didanosine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'pH change', 'Decreased absorption', 'Separate administration.');
add('Ketoconazole', H2_ANTAGONISTS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'pH change', 'Decreased absorption', 'Use acid drink.');
add('Ketoconazole', HYDANTOINS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased ketoconazole levels', 'Avoid combination.');
add('Ketoconazole', 'Indinavir', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased indinavir levels', 'Monitor levels.');
add('Ketoconazole', PPIS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'pH change', 'Decreased absorption', 'Use acid drink.');
add('Voriconazole', BARBITURATES, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Induction', 'Decreased voriconazole levels', 'Avoid combination.');
add('Voriconazole', 'Carbamazepine', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Induction', 'Decreased voriconazole levels', 'Avoid combination.');
add('Voriconazole', 'Ergot Alkaloids', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Ergotism', 'Avoid combination.');
add('Voriconazole', 'Pimozide', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'QT Prolongation', 'Arrhythmias', 'Avoid combination.');
add('Voriconazole', 'Quinidine', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'QT Prolongation', 'Arrhythmias', 'Avoid combination.');

// Misc Antifungal & Antimycobacterial
add('Griseofulvin', BARBITURATES, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased griseofulvin levels', 'Increase dose.');
add('Griseofulvin', 'Warfarin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased warfarin effect', 'Monitor INR.');
add('Caspofungin', 'Cyclosporine', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Unknown', 'Hepatic toxicity', 'Avoid combination.');
add('Caspofungin', 'Tacrolimus', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Unknown', 'Decreased tacrolimus levels', 'Monitor levels.');
add('Aminosalicylic acid', 'Rifampin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Absorption', 'Decreased rifampin levels', 'Separate administration.');
add('Isoniazid', 'Carbamazepine', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Carbamazepine toxicity', 'Monitor levels.');
add('Isoniazid', 'Phenytoin', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Phenytoin toxicity', 'Monitor levels.');
add('Isoniazid', 'Rifampin', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Additive', 'Hepatotoxicity', 'Monitor liver function.');

add(RIFAMYCINS, AZOLE_ANTIFUNGALS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Induction', 'Decreased antifungal levels', 'Avoid combination.');
add(RIFAMYCINS, 'Bisoprolol', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased beta-blocker effect', 'Monitor CV status.');
add(RIFAMYCINS, 'Buspirone', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased buspirone effect', 'Monitor levels.');
add(RIFAMYCINS, 'Clarithromycin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased macrolide effect', 'Use alternative.');
add(RIFAMYCINS, CORTICOSTEROIDS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Induction', 'Decreased steroid effect', 'Increase steroid dose.');
add(RIFAMYCINS, 'Cyclosporine', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Induction', 'Organ rejection', 'Increase dose.');
add(RIFAMYCINS, 'Delavirdine', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Induction', 'Decreased delavirdine levels', 'Avoid combination.');
add(RIFAMYCINS, 'Doxycycline', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased doxycycline levels', 'Increase dose.');
add(RIFAMYCINS, 'Erythromycin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased macrolide effect', 'Use alternative.');
add(RIFAMYCINS, 'Estrogens', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Contraceptive failure', 'Use alternative.');
add(RIFAMYCINS, 'Haloperidol', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased antipsychotic effect', 'Monitor levels.');
add(RIFAMYCINS, STATINS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Induction', 'Decreased statin effect', 'Monitor lipids.');
add(RIFAMYCINS, 'Indinavir', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Induction', 'Decreased indinavir levels', 'Avoid combination.');
add(RIFAMYCINS, 'Methadone', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Induction', 'Withdrawal symptoms', 'Increase methadone dose.');
add(RIFAMYCINS, 'Morphine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased analgesic effect', 'Monitor pain.');
add(RIFAMYCINS, 'Nelfinavir', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Induction', 'Decreased nelfinavir levels', 'Avoid combination.');
add(RIFAMYCINS, 'Phenytoin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased phenytoin levels', 'Monitor levels.');
add(RIFAMYCINS, 'Quinidine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased quinidine levels', 'Monitor levels.');
add(RIFAMYCINS, 'Quinine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased quinine levels', 'Monitor levels.');
add(RIFAMYCINS, SULFONYLUREAS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Hyperglycemia', 'Monitor glucose.');
add(RIFAMYCINS, 'Tacrolimus', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Induction', 'Decreased tacrolimus levels', 'Monitor levels.');
add(RIFAMYCINS, 'Theophylline', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased theophylline levels', 'Monitor levels.');
add(RIFAMYCINS, TCAS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased antidepressant effect', 'Monitor levels.');
add(RIFAMYCINS, 'Warfarin', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Induction', 'Decreased INR', 'Increase warfarin dose.');
add('Rifampin', 'Isoniazid', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Additive', 'Hepatotoxicity', 'Monitor LFTs.');
add('Rifampin', 'Nifedipine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased nifedipine effect', 'Adjust dose.');
add('Rifampin', 'Verapamil', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased verapamil effect', 'Adjust dose.');

// Antivirals
add('Acyclovir', 'Theophylline', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Renal competition', 'Increased theophylline levels', 'Monitor levels.');
add('Delavirdine', 'Ergot Alkaloids', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Ergotism', 'Avoid combination.');
add('Delavirdine', RIFAMYCINS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Induction', 'Decreased delavirdine levels', 'Avoid combination.');
add('Didanosine', 'Food', InteractionType.DRUG_FOOD, InteractionSeverity.MODERATE, 'Absorption', 'Decreased absorption', 'Take on empty stomach.');
add('Didanosine', 'Indinavir', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'pH change', 'Decreased absorption', 'Separate administration.');
add('Didanosine', 'Itraconazole', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'pH change', 'Decreased absorption', 'Separate administration.');
add('Didanosine', 'Ketoconazole', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'pH change', 'Decreased absorption', 'Separate administration.');
add('Didanosine', QUINOLONES, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Chelation', 'Decreased quinolone absorption', 'Separate administration.');
add('Foscarnet', 'Cyclosporine', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Additive', 'Renal failure', 'Avoid combination.');
add('Ganciclovir', 'Zidovudine', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Additive', 'Hematologic toxicity', 'Avoid combination.');
add('Indinavir', AZOLE_ANTIFUNGALS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased indinavir levels', 'Decrease dose.');
add('Indinavir', BENZODIAZEPINES, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased sedation', 'Avoid combination.');
add('Indinavir', 'Didanosine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'pH change', 'Decreased absorption', 'Separate administration.');
add('Indinavir', 'Ergot Alkaloids', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Ergotism', 'Avoid combination.');
add('Indinavir', 'Methadone', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Withdrawal', 'Monitor levels.');
add('Indinavir', RIFAMYCINS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Induction', 'Decreased indinavir levels', 'Avoid combination.');
add('Nelfinavir', AZOLE_ANTIFUNGALS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased nelfinavir levels', 'Decrease dose.');
add('Nelfinavir', 'Ergot Alkaloids', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Ergotism', 'Avoid combination.');
add('Nelfinavir', 'Ethinyl Estradiol', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Induction', 'Contraceptive failure', 'Use alternative contraception.');
add('Nelfinavir', 'Methadone', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Withdrawal', 'Monitor levels.');
add('Nelfinavir', RIFAMYCINS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Induction', 'Decreased nelfinavir levels', 'Avoid combination.');
add('Ritonavir', 'Amiodarone', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Amiodarone toxicity', 'Avoid combination.');
add('Ritonavir', AZOLE_ANTIFUNGALS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased azole levels', 'Decrease dose.');
add('Ritonavir', BENZODIAZEPINES, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased sedation', 'Avoid combination.');
add('Ritonavir', 'Bupropion', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Seizure risk', 'Avoid combination.');
add('Ritonavir', 'Clozapine', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Clozapine toxicity', 'Avoid combination.');
add('Ritonavir', 'Encainide', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Arrhythmias', 'Avoid combination.');
add('Ritonavir', 'Ergot Alkaloids', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Ergotism', 'Avoid combination.');
add('Ritonavir', 'Ethinyl Estradiol', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Induction', 'Contraceptive failure', 'Use alternative contraception.');
add('Ritonavir', 'Flecainide', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Arrhythmias', 'Avoid combination.');
add('Ritonavir', 'Meperidine', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Neurotoxicity', 'Avoid combination.');
add('Ritonavir', 'Piroxicam', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'NSAID toxicity', 'Avoid combination.');
add('Ritonavir', 'Propafenone', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Propafenone toxicity', 'Avoid combination.');
add('Ritonavir', 'Propoxyphene', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Propoxyphene toxicity', 'Avoid combination.');
add('Ritonavir', 'Quinidine', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Quinidine toxicity', 'Avoid combination.');
add('Ritonavir', RIFAMYCINS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Induction', 'Decreased ritonavir levels', 'Avoid combination.');
add('Saquinavir', BENZODIAZEPINES, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased sedation', 'Avoid combination.');
add('Saquinavir', 'Ergot Alkaloids', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Ergotism', 'Avoid combination.');
add('Saquinavir', 'Grapefruit Juice', InteractionType.DRUG_FOOD, InteractionSeverity.MODERATE, 'Inhibition', 'Increased saquinavir levels', 'Avoid combination.');
add('Zidovudine', 'Atovaquone', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased zidovudine levels', 'Monitor for toxicity.');
add('Zidovudine', 'Ganciclovir', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Additive', 'Hematologic toxicity', 'Avoid combination.');
add('Zidovudine', 'Probenecid', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Reduced clearance', 'Zidovudine toxicity', 'Monitor for toxicity.');

// 8. Anticoagulants
add('Alteplase', 'Nitroglycerin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Unknown', 'Decreased tPA effect', 'Avoid combination.');
add('Dipyridamole', 'Adenosine', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition of uptake', 'Increased adenosine effect', 'Decrease adenosine dose.');
add('Heparin', 'Aspirin', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Additive', 'Bleeding risk', 'Monitor bleeding.');
add('Ticlopidine', 'Phenytoin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased phenytoin levels', 'Monitor levels.');
add('Ticlopidine', 'Theophylline', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased theophylline levels', 'Monitor levels.');
add('Warfarin', 'Acetaminophen', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Metabolic', 'Increased INR', 'Monitor INR.');
add('Warfarin', 'Aminoglutethimide', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased INR', 'Monitor INR.');
add('Warfarin', 'Amiodarone', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased INR', 'Decrease warfarin dose.');
add('Warfarin', ANDROGENS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Metabolic', 'Increased INR', 'Monitor INR.');
add('Warfarin', AZOLE_ANTIFUNGALS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased INR', 'Monitor INR.');
add('Warfarin', BARBITURATES, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Induction', 'Decreased INR', 'Increase warfarin dose.');
add('Warfarin', 'Carbamazepine', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Induction', 'Decreased INR', 'Increase warfarin dose.');
add('Warfarin', CEPHALOSPORINS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Vitamin K inhibition', 'Increased INR', 'Monitor INR.');
add('Warfarin', 'Chloramphenicol', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased INR', 'Monitor INR.');
add('Warfarin', 'Cholestyramine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Binding', 'Decreased warfarin effect', 'Separate administration.');
add('Warfarin', 'Cimetidine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased INR', 'Use ranitidine.');
add('Warfarin', 'Dextrothyroxine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Metabolic', 'Increased INR', 'Monitor INR.');
add('Warfarin', 'Disulfiram', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased INR', 'Monitor INR.');
add('Warfarin', 'Ethchlorvynol', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased INR', 'Monitor INR.');
add('Warfarin', FIBRATES, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Displacement', 'Increased INR', 'Avoid combination.');
add('Warfarin', 'Glucagon', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Unknown', 'Increased INR', 'Monitor INR.');
add('Warfarin', 'Glutethimide', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased INR', 'Monitor INR.');
add('Warfarin', 'Griseofulvin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased INR', 'Monitor INR.');
add('Warfarin', STATINS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Metabolic', 'Increased INR', 'Monitor INR.');
add('Warfarin', 'Levamisole', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Unknown', 'Increased INR', 'Monitor INR.');
add('Warfarin', MACROLIDES, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased INR', 'Monitor INR.');
add('Warfarin', 'Metronidazole', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased INR', 'Monitor INR.');
add('Warfarin', 'Nalidixic Acid', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Displacement', 'Increased INR', 'Monitor INR.');
add('Warfarin', NSAIDS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Additive', 'Bleeding risk', 'Avoid combination.');
add('Warfarin', PENICILLINS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Unknown', 'Increased INR', 'Monitor INR.');
add('Warfarin', ['Quinidine', 'Quinine'], InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Unknown', 'Increased INR', 'Monitor INR.');
add('Warfarin', RIFAMYCINS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased INR', 'Increase warfarin dose.');
add('Warfarin', 'Salicylates', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Additive', 'Bleeding risk', 'Avoid combination.');
add('Warfarin', 'Sulfinpyrazone', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Increased INR', 'Monitor INR.');
add('Warfarin', SULFONAMIDES, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased INR', 'Monitor INR.');
add('Warfarin', THIOAMIDES, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Metabolic', 'Altered INR', 'Monitor INR.');
add('Warfarin', THYROID_HORMONES, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Metabolic', 'Increased INR', 'Monitor INR.');
add('Warfarin', 'Vitamin E', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Unknown', 'Increased INR', 'Monitor INR.');
add('Warfarin', 'Vitamin K', InteractionType.DRUG_FOOD, InteractionSeverity.HIGH, 'Antagonism', 'Decreased INR', 'Consistent diet.');

// 9. Anticonvulsants
add('Carbamazepine', 'Bupropion', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased bupropion levels', 'Increase dose.');
add('Carbamazepine', 'Cimetidine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Carbamazepine toxicity', 'Use ranitidine.');
add('Carbamazepine', 'Cyclosporine', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Induction', 'Rejection risk', 'Increase cyclosporine dose.');
add('Carbamazepine', 'Danazol', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Carbamazepine toxicity', 'Avoid combination.');
add('Carbamazepine', 'Diltiazem', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Carbamazepine toxicity', 'Decrease carbamazepine dose.');
add('Carbamazepine', 'Doxycycline', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased doxycycline levels', 'Increase dose.');
add('Carbamazepine', 'Felodipine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased felodipine effect', 'Monitor BP.');
add('Carbamazepine', 'Fluoxetine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Carbamazepine toxicity', 'Monitor levels.');
add('Carbamazepine', 'Grapefruit Juice', InteractionType.DRUG_FOOD, InteractionSeverity.MODERATE, 'Inhibition', 'Carbamazepine toxicity', 'Avoid combination.');
add('Carbamazepine', 'Haloperidol', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased haloperidol effect', 'Monitor status.');
add('Carbamazepine', 'Isoniazid', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Metabolic', 'Hepatotoxicity', 'Monitor liver function.');
add('Carbamazepine', 'Lamotrigine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased lamotrigine levels', 'Adjust doses.');
add('Carbamazepine', 'Lithium', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Unknown', 'Neurotoxicity', 'Monitor status.');
add('Carbamazepine', MACROLIDES, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Carbamazepine toxicity', 'Avoid combination.');
add('Carbamazepine', MAOI_INHIBITORS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Unknown', 'Hypertensive crisis', 'Avoid combination.');
add('Carbamazepine', 'Nefazodone', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Carbamazepine toxicity', 'Avoid combination.');
add('Carbamazepine', 'Phenytoin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased carbamazepine levels', 'Monitor levels.');
add('Carbamazepine', 'Primidone', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased primidone levels', 'Monitor levels.');
add('Carbamazepine', 'Propoxyphene', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Carbamazepine toxicity', 'Avoid combination.');
add('Carbamazepine', TCAS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased TCA levels', 'Monitor levels.');
add('Carbamazepine', 'Valproic Acid', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Metabolic', 'Decreased valproic acid', 'Monitor levels.');
add('Carbamazepine', 'Verapamil', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Carbamazepine toxicity', 'Decrease carbamazepine dose.');

add('Lamotrigine', 'Warfarin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Unknown', 'Altered INR', 'Monitor INR.');
add('Lamotrigine', 'Carbamazepine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased lamotrigine levels', 'Adjust doses.');
add('Lamotrigine', 'Valproic Acid', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Increased lamotrigine levels', 'Decrease lamotrigine dose.');

add('Phenobarbital', 'Warfarin', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Induction', 'Decreased INR', 'Increase warfarin dose.');
add('Phenobarbital', BETA_BLOCKERS_ALL, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased beta-blocker effect', 'Increase dose.');
add('Phenobarbital', CORTICOSTEROIDS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased steroid effect', 'Increase steroid dose.');
add('Phenobarbital', 'Doxycycline', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased doxycycline effect', 'Increase dose.');
add('Phenobarbital', 'Estrogens', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Contraceptive failure', 'Use alternative.');
add('Phenobarbital', 'Ethanol', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Additive', 'CNS depression', 'Avoid alcohol.');
add('Phenobarbital', 'Felodipine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased felodipine effect', 'Monitor BP.');
add('Phenobarbital', 'Griseofulvin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased griseofulvin effect', 'Increase dose.');
add('Phenobarbital', 'Methadone', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Withdrawal symptoms', 'Increase methadone dose.');
add('Phenobarbital', 'Metronidazole', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Therapeutic failure', 'Increase dose.');
add('Phenobarbital', 'Nifedipine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased nifedipine effect', 'Increase dose.');
add('Phenobarbital', 'Quinidine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased quinidine effect', 'Increase dose.');
add('Phenobarbital', 'Theophylline', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased theophylline effect', 'Increase dose.');
add('Phenobarbital', 'Valproic Acid', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Phenobarbital toxicity', 'Decrease phenobarbital dose.');
add('Phenobarbital', 'Voriconazole', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Induction', 'Decreased voriconazole effect', 'Avoid combination.');

add(HYDANTOINS, 'Warfarin', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Induction/Inhibition', 'Altered INR', 'Monitor INR.');
add(HYDANTOINS, BARBITURATES, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Metabolic', 'Altered levels', 'Monitor levels.');
add(HYDANTOINS, 'Amiodarone', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Metabolic', 'Phenytoin toxicity', 'Monitor levels.');
add(HYDANTOINS, ANTINEOPLASTICS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Metabolic', 'Decreased phenytoin levels', 'Monitor levels.');
add(HYDANTOINS, 'Carbamazepine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Metabolic', 'Altered levels', 'Monitor levels.');
add(HYDANTOINS, 'Chloramphenicol', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Phenytoin toxicity', 'Monitor levels.');
add(HYDANTOINS, 'Cimetidine', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Phenytoin toxicity', 'Use ranitidine.');
add(HYDANTOINS, CORTICOSTEROIDS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased steroid effect', 'Increase dose.');
add(HYDANTOINS, 'Cyclosporine', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Induction', 'Rejection risk', 'Increase dose.');
add(HYDANTOINS, 'Diazoxide', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Metabolic', 'Decreased phenytoin levels', 'Monitor levels.');
add(HYDANTOINS, 'Disopyramide', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased disopyramide effect', 'Monitor CV status.');
add(HYDANTOINS, 'Disulfiram', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Phenytoin toxicity', 'Monitor levels.');
add(HYDANTOINS, 'Dopamine', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Unknown', 'Hypotension/Cardiac arrest', 'Monitor BP.');
add(HYDANTOINS, 'Doxycycline', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased doxycycline effect', 'Increase dose.');
add(HYDANTOINS, 'Estrogens', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Contraceptive failure', 'Use alternative.');
add(HYDANTOINS, 'Felodipine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased felodipine effect', 'Monitor BP.');
add(HYDANTOINS, 'Fluconazole', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Phenytoin toxicity', 'Monitor levels.');
add(HYDANTOINS, 'Fluoxetine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Phenytoin toxicity', 'Monitor levels.');
add(HYDANTOINS, 'Folic acid', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Metabolic', 'Decreased phenytoin levels', 'Monitor levels.');
add(HYDANTOINS, 'Isoniazid', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Phenytoin toxicity', 'Monitor levels.');
add(HYDANTOINS, 'Itraconazole', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased itraconazole effect', 'Avoid combination.');
add(HYDANTOINS, 'Ketoconazole', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased ketoconazole effect', 'Avoid combination.');
add(HYDANTOINS, 'Levodopa', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased levodopa effect', 'Increase levodopa dose.');
add(HYDANTOINS, 'Methadone', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Withdrawal symptoms', 'Increase methadone dose.');
add(HYDANTOINS, 'Mexiletine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased mexiletine effect', 'Increase mexiletine dose.');
add(HYDANTOINS, 'Nisoldipine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased nisoldipine effect', 'Adjust dose.');
add(HYDANTOINS, 'Quinidine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased quinidine effect', 'Monitor levels.');
add(HYDANTOINS, RIFAMYCINS, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased phenytoin levels', 'Monitor levels.');
add(HYDANTOINS, 'Sertraline', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Phenytoin toxicity', 'Monitor levels.');
add(HYDANTOINS, 'Sucralfate', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Absorption', 'Decreased phenytoin absorption', 'Separate administration.');
add(HYDANTOINS, SULFONAMIDES, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Phenytoin toxicity', 'Monitor levels.');
add(HYDANTOINS, 'Tacrolimus', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Induction', 'Rejection risk', 'Increase tacrolimus dose.');
add(HYDANTOINS, 'Theophylline', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Induction', 'Decreased levels of both', 'Monitor levels.');
add(HYDANTOINS, 'Ticlopidine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Phenytoin toxicity', 'Monitor levels.');
add(HYDANTOINS, 'Trimethoprim', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Phenytoin toxicity', 'Monitor levels.');
add(HYDANTOINS, 'Valproic Acid', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Displacement', 'Phenytoin toxicity', 'Monitor free phenytoin.');

add('Valproic Acid', BARBITURATES, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Inhibition', 'Barbiturate toxicity', 'Decrease barbiturate dose.');
add('Valproic Acid', 'Carbamazepine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Metabolic', 'Decreased valproic acid', 'Monitor levels.');
add('Valproic Acid', 'Cholestyramine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Absorption', 'Decreased valproic acid absorption', 'Separate administration.');
add('Valproic Acid', 'Lamotrigine', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Lamotrigine toxicity', 'Decrease lamotrigine dose.');
add('Valproic Acid', 'Phenytoin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Displacement', 'Increased free valproic acid', 'Monitor levels.');
add('Valproic Acid', 'Salicylates', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Displacement', 'Valproic acid toxicity', 'Monitor levels.');

// 10. Antineoplastics & Antiparkinson
add('Azathioprine', 'Allopurinol', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Inhibition', 'Bone marrow toxicity', 'Reduce azathioprine dose to 25%.');
add('Methotrexate', NSAIDS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Reduced clearance', 'Methotrexate toxicity', 'Avoid combination.');
add('Methotrexate', PENICILLINS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Reduced clearance', 'Methotrexate toxicity', 'Monitor levels.');
add('Methotrexate', 'Probenecid', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Reduced clearance', 'Methotrexate toxicity', 'Avoid combination.');
add('Methotrexate', 'Salicylates', InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Reduced clearance', 'Methotrexate toxicity', 'Avoid combination.');
add('Methotrexate', SULFONAMIDES, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Displacement', 'Methotrexate toxicity', 'Avoid combination.');

add('Levodopa', 'Iron', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Chelation', 'Decreased levodopa absorption', 'Separate administration.');
add('Levodopa', MAOI_INHIBITORS, InteractionType.DRUG_DRUG, InteractionSeverity.HIGH, 'Unknown', 'Hypertensive crisis', 'Avoid combination.');
add('Levodopa', 'Metoclopramide', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Motility', 'Increased levodopa absorption', 'Monitor for dyskinesia.');
add('Levodopa', PHENOTHIAZINES, InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Antagonism', 'Decreased levodopa effect', 'Increase dose.');
add('Levodopa', 'Phenytoin', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Antagonism', 'Decreased levodopa effect', 'Increase dose.');
add('Levodopa', 'Pyridoxine', InteractionType.DRUG_DRUG, InteractionSeverity.MODERATE, 'Metabolic', 'Decreased levodopa effect', 'Avoid supplements.');


export const CLEAN_INTERACTIONS = processInteractions(rawInteractions);
export const DRUG_LIST = extractUniqueDrugs(CLEAN_INTERACTIONS);
