
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { CLEAN_INTERACTIONS, DRUG_LIST } from './data/database';
import { InteractionData } from './types';
import InteractionCard from './components/InteractionCard';

// Reusable Search Input Component
interface SearchInputProps {
  label: string;
  placeholder: string;
  value: string;
  onChange: (val: string) => void;
  onSelect: (val: string) => void;
  suggestions: { id: string; name: string }[];
  icon: React.ReactNode;
}

const SearchInput: React.FC<SearchInputProps> = ({ label, placeholder, value, onChange, onSelect, suggestions, icon }) => {
  const [showSuggestions, setShowSuggestions] = useState(false);
  const wrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [wrapperRef]);

  return (
    <div className="relative w-full" ref={wrapperRef}>
      <label className="block text-sm font-semibold text-slate-700 mb-2">{label}</label>
      <div className="relative">
        <div className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400">
          {icon}
        </div>
        <input
          type="text"
          className="w-full p-3 pr-10 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none shadow-sm transition-all"
          placeholder={placeholder}
          value={value}
          onChange={(e) => {
            onChange(e.target.value);
            setShowSuggestions(true);
          }}
          onFocus={() => setShowSuggestions(true)}
        />
        {value && (
          <button 
            onClick={() => onChange('')}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-red-500"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
            </svg>
          </button>
        )}
      </div>

      {/* Suggestions Dropdown */}
      {showSuggestions && suggestions.length > 0 && (
        <div className="absolute w-full bg-white mt-1 rounded-xl shadow-lg border border-slate-100 overflow-hidden z-20 text-right max-h-60 overflow-y-auto custom-scrollbar">
          {suggestions.map((item) => (
            <div
              key={item.id}
              className="p-3 hover:bg-blue-50 cursor-pointer transition-colors border-b border-slate-50 last:border-none text-sm font-medium text-slate-700"
              onClick={() => {
                onSelect(item.name);
                setShowSuggestions(false);
              }}
            >
              {item.name}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

function App() {
  const [term1, setTerm1] = useState('');
  const [term2, setTerm2] = useState('');

  // Suggestions logic
  const getSuggestions = (query: string) => {
    if (!query) return [];
    return DRUG_LIST.filter(drug => 
      drug.name.toLowerCase().includes(query.toLowerCase())
    ).slice(0, 10);
  };

  const suggestions1 = useMemo(() => getSuggestions(term1), [term1]);
  const suggestions2 = useMemo(() => getSuggestions(term2), [term2]);

  // Filtering logic
  const filteredInteractions = useMemo(() => {
    // If both empty, show nothing or recent
    if (!term1 && !term2) return [];

    const t1 = term1.trim().toLowerCase();
    const t2 = term2.trim().toLowerCase();

    return CLEAN_INTERACTIONS.filter((item) => {
      const drugA = item.drugA.toLowerCase();
      const drugB = (item.drugB || '').toLowerCase();
      const foodOrCond = (item.foodOrCondition || '').toLowerCase();
      
      const parties = [drugA, drugB, foodOrCond].filter(Boolean); // All parties in this interaction

      // Case 1: Only Term 1 is entered -> Show all interactions involving Term 1
      if (t1 && !t2) {
        return parties.some(p => p.includes(t1));
      }

      // Case 2: Only Term 2 is entered -> Show all interactions involving Term 2
      if (!t1 && t2) {
        return parties.some(p => p.includes(t2));
      }

      // Case 3: Both entered -> Show intersection
      // Check if the interaction contains BOTH terms
      const match1 = parties.some(p => p.includes(t1));
      const match2 = parties.some(p => p.includes(t2));
      
      return match1 && match2;
    });
  }, [term1, term2]);

  return (
    <div className="min-h-screen bg-slate-50 text-right font-sans" dir="rtl">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50 shadow-sm">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center text-white font-bold text-xl shadow-blue-200 shadow-lg">
              Rx
            </div>
            <h1 className="text-xl font-bold text-slate-800 tracking-tight">PharmaCheck <span className="text-blue-600">Pro</span></h1>
          </div>
          <div className="flex items-center gap-3">
             <div className="text-xs font-bold text-indigo-600 bg-indigo-50 border border-indigo-100 px-3 py-1 rounded-full">
              {CLEAN_INTERACTIONS.length.toLocaleString()} تفاعل
            </div>
            <div className="text-xs font-medium text-slate-500 hidden md:block bg-slate-100 px-3 py-1 rounded-full">
              قاعدة بيانات طبية شاملة
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-8">
        
        {/* Search Section */}
        <div className="bg-white rounded-2xl p-6 md:p-8 shadow-lg border border-slate-100 mb-8 relative overflow-hidden">
          {/* Decorative background element */}
          <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500"></div>

          <div className="text-center mb-8">
            <h2 className="text-2xl md:text-3xl font-bold text-slate-900 mb-3">فحص التداخلات الدوائية</h2>
            <p className="text-slate-500 text-lg">أدخل دواءين، أو دواء وطعام/مرض للتحقق من السلامة</p>
          </div>
          
          <div className="flex flex-col md:flex-row items-center gap-4 relative">
            
            {/* Input 1 */}
            <div className="w-full z-20">
              <SearchInput 
                label="الطرف الأول"
                placeholder="مثال: Warfarin, Aspirin..."
                value={term1}
                onChange={setTerm1}
                onSelect={setTerm1}
                suggestions={suggestions1}
                icon={
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
                  </svg>
                }
              />
            </div>

            {/* Interaction Icon */}
            <div className="shrink-0 z-10 flex items-center justify-center w-10 h-10 rounded-full bg-blue-50 text-blue-600 mt-6 md:mt-6 shadow-sm border border-blue-100">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
              </svg>
            </div>

            {/* Input 2 */}
            <div className="w-full z-20">
              <SearchInput 
                label="الطرف الثاني (دواء / غذاء / مرض)"
                placeholder="مثال: Garlic, Hypertension, Ibuprofen..."
                value={term2}
                onChange={setTerm2}
                onSelect={setTerm2}
                suggestions={suggestions2}
                icon={
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                  </svg>
                }
              />
            </div>
          </div>

          {/* Status Indicator */}
          {(term1 && term2) && (
            <div className="mt-6 p-3 bg-slate-50 rounded-lg border border-slate-200 text-center text-sm text-slate-600 flex items-center justify-center gap-2">
              <span>جاري البحث عن التفاعل بين:</span>
              <span className="font-bold text-blue-700">{term1}</span>
              <span>و</span>
              <span className="font-bold text-purple-700">{term2}</span>
            </div>
          )}
        </div>

        {/* Results Section */}
        <div className="space-y-4">
          <div className="flex items-center justify-between mb-4 px-1">
            <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
              <span className="w-2 h-6 bg-blue-500 rounded-full block"></span>
              النتائج
            </h3>
            {filteredInteractions.length > 0 && (
              <span className="text-xs font-bold text-white bg-slate-800 px-3 py-1 rounded-full shadow-sm">
                تم العثور على {filteredInteractions.length} نتيجة
              </span>
            )}
          </div>

          {filteredInteractions.length === 0 ? (
            <div className="text-center py-16 bg-white rounded-2xl border border-dashed border-slate-300 shadow-sm">
              <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
              <h3 className="text-lg font-medium text-slate-900 mb-1">لا توجد نتائج</h3>
              <p className="text-slate-500 max-w-xs mx-auto">
                {!term1 && !term2 ? 'ابدأ بكتابة اسم دواء أو غذاء في الخانات أعلاه' : 'لم يتم العثور على تفاعلات مسجلة بين هذه العناصر في قاعدة البيانات.'}
              </p>
            </div>
          ) : (
            <div className="grid gap-6">
              {filteredInteractions.map((interaction) => (
                <InteractionCard key={interaction.id} interaction={interaction} />
              ))}
            </div>
          )}
        </div>

      </main>
      
      <footer className="bg-white border-t border-slate-200 py-10 mt-12">
        <div className="max-w-5xl mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
             <div className="w-6 h-6 bg-slate-200 rounded-md flex items-center justify-center text-slate-600 font-bold text-xs">Rx</div>
             <span className="font-bold text-slate-700">PharmaCheck Pro</span>
          </div>
          <p className="text-slate-500 text-sm mb-4 max-w-lg mx-auto">
            تم تطوير هذا التطبيق لغايات تعليمية وطبية مهنية لمساعدة الصيادلة والأطباء في التحقق السريع من التداخلات الدوائية.
          </p>
          <p className="text-slate-400 text-xs">
            يحتوي على قاعدة بيانات لـ <span className="font-bold text-slate-600">{CLEAN_INTERACTIONS.length.toLocaleString()}</span> تفاعل دوائي.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;
